import React, { memo, useMemo } from 'react';
import { DollarSign, Target, Calendar, TrendingUp } from 'lucide-react';
import { StatsCard } from './StatsCard';
import { SalesChart } from './SalesChart';
import { PossibleCommissions } from './PossibleCommissions';
import { GuaranteedCommissions } from './GuaranteedCommissions';
import { EmployeeHighlight } from './EmployeeHighlight';
import { CommercialGoalCard } from './CommercialGoalCard';
import { useSupabaseQuery } from '../../hooks/useSupabase';
import { PartyPopper, X, Info } from 'lucide-react';
import { useMonthlyGoals } from '../../hooks/useMonthlyGoals';
import { formatCurrency } from '../../utils/formatCurrency';
import { useYear } from '../../contexts/YearContext';

export const Dashboard: React.FC = memo(() => {
  const { selectedYear } = useYear();
  // Calculate current month and year first
  const currentMonth = new Date().getMonth();
  const currentYear = selectedYear;
  
  // Otimizar queries com select específico
  const { data: employees = [], loading: employeesLoading } = useSupabaseQuery('employees', {
    select: 'id, name, avatar, role, department, points, level'
  });
  
  const { data: proposals = [], loading: proposalsLoading } = useSupabaseQuery('proposals', {
    select: 'id, client, monthly_value, months, total_value, status, commission, closer_id, sdr_id, closing_date, created_at'
  });
  
  const { data: weeklyPerformanceData = [], loading: weeklyLoading } = useSupabaseQuery('weekly_performance', {
    select: 'employee_id, week_ending_date, total_points, visitas_agendadas'
  });
  
  const { getMonthGoal, getAnnualGoal } = useMonthlyGoals();
  
  const [showPersonCommissionModal, setShowPersonCommissionModal] = React.useState<{employeeId: string, displayRate: number} | null>(null);

  // Memoizar cálculos pesados
  const dashboardStats = useMemo(() => {
    if (employeesLoading || proposalsLoading || weeklyLoading) return null;
    
    // Filtrar apenas propostas em aberto (Proposta + Negociação)
    const openProposals = proposals.filter(p => p.status === 'Proposta' || p.status === 'Negociação');
    
    // Valor em propostas em aberto
    const totalOpenProposalValue = openProposals.reduce((sum, p) => sum + (p.total_value || 0), 0);
    
    // Comissões possíveis das propostas em aberto (somando por pessoa envolvida)
    const calculatePossibleCommissions = () => {
      const commissionsByEmployee: { [key: string]: { closerCommission: number, sdrCommission: number } } = {};
      
      openProposals.forEach(proposal => {
        const proposalCommission = Number(proposal.commission || 0);
        
        // Comissão do Closer
        if (proposal.closer_id) {
          if (!commissionsByEmployee[proposal.closer_id]) {
            commissionsByEmployee[proposal.closer_id] = { closerCommission: 0, sdrCommission: 0 };
          }
          commissionsByEmployee[proposal.closer_id].closerCommission += proposalCommission;
        }
        
        // Comissão do SDR (mesma comissão que o closer)
        if (proposal.sdr_id) {
          if (!commissionsByEmployee[proposal.sdr_id]) {
            commissionsByEmployee[proposal.sdr_id] = { closerCommission: 0, sdrCommission: 0 };
          }
          commissionsByEmployee[proposal.sdr_id].sdrCommission += proposalCommission;
        }
      });
      
      return Object.values(commissionsByEmployee).reduce(
        (sum, employee) => sum + employee.closerCommission + employee.sdrCommission, 0
      );
    };
    
    const totalPossibleCommissions = calculatePossibleCommissions();
    
    const closedDealsThisMonth = proposals.filter(proposal => {
      if (proposal.status !== 'Fechado') return false;
      const dateToCheck = proposal.closing_date || proposal.created_at;
      if (!dateToCheck) return false;
      const dealDate = new Date(dateToCheck);
      return dealDate.getMonth() === currentMonth && dealDate.getFullYear() === currentYear;
    }).length;
    
    // Agendamentos - buscar visitas agendadas de SDRs no mês atual
    const totalAppointments = weeklyPerformanceData
      .filter(weekData => {
        // Filtrar apenas SDRs
        const employee = employees.find(emp => emp.id === weekData.employee_id);
        if (!employee || employee.role !== 'SDR') return false;
        
        // Filtrar apenas dados do mês atual
        const weekDate = new Date(weekData.week_ending_date);
        return weekDate.getMonth() === currentMonth && weekDate.getFullYear() === currentYear;
      })
      .reduce((sum, weekData) => sum + (weekData.visitas_agendadas || 0), 0);
    
    return {
      totalOpenProposalValue,
      totalPossibleCommissions,
      closedDealsThisMonth,
      totalAppointments
    };
  }, [proposals, weeklyPerformanceData, currentMonth, currentYear, employeesLoading, proposalsLoading, weeklyLoading]);
  
  if (employeesLoading || proposalsLoading || weeklyLoading) {
    return (
      <div className="flex items-center justify-center py-12 min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <div className="text-lg text-gray-700">Carregando Dashboard...</div>
        </div>
      </div>
    );
  }
  
  if (!dashboardStats) return null;
  
  const { totalOpenProposalValue, totalPossibleCommissions, closedDealsThisMonth, totalAppointments } = dashboardStats;
  const closedContractsThisMonth = proposals.filter(proposal => {
    if (proposal.status !== 'Fechado') return false;
    
    // Usar data de fechamento se disponível, senão usar data de criação
    const dateToCheck = proposal.closing_date || proposal.created_at;
    if (!dateToCheck) return false;
    
    const closingDate = new Date(dateToCheck);
    return closingDate.getMonth() === currentMonth && closingDate.getFullYear() === currentYear;
  });
  
  const totalClosedValueThisMonth = closedContractsThisMonth.reduce(
    (sum, proposal) => sum + Number(proposal.total_value || 0), 0
  );
  
  // Determinar taxa de comissão baseada no volume total
  const getCommissionRate = (totalValue: number) => {
    if (totalValue <= 600000) return 0.4;
    if (totalValue <= 1200000) return 0.8;
    return 1.2;
  };
  
  const currentCommissionRate = getCommissionRate(totalClosedValueThisMonth);
  const nextTierThreshold = totalClosedValueThisMonth <= 600000 ? 600000 : 1200000;
  const remainingToNextTier = nextTierThreshold - totalClosedValueThisMonth;
  
  const recentProposals = proposals.slice(0, 3);
  const activeProposals = proposals.filter(p => 
    p.status === 'Proposta' || p.status === 'Negociação'
  );
  
  // Estatísticas excluindo propostas perdidas
  const validProposals = proposals.filter(p => p.status !== 'Perdido');
  
  // Calcular comissões possíveis (apenas propostas ativas)
  const possibleProposals = proposals.filter(p => 
    p.status === 'Proposta' || p.status === 'Negociação'
  );
  
  // Supermeta: comissões com 0.8% (dobro da base)
  const supermetaCommissions = possibleProposals.reduce((sum, p) => {
    const superCommission = (p.total_value || 0) * 0.008; // 0.8%
    const closerCommission = p.closer_id ? superCommission : 0;
    const sdrCommission = p.sdr_id ? superCommission : 0;
    return sum + closerCommission + sdrCommission;
  }, 0);
  
  const supermetaTarget = 600000; // Meta de R$ 600k
  const supermetaProgress = Math.min((totalClosedValueThisMonth / supermetaTarget) * 100, 100);
  
  // Generate closer stats from real employees data
  const closerStats = employees
    .filter(emp => emp.role === 'Closer')
    .map(closer => ({
      id: closer.id,
      name: closer.name,
      avatar: closer.avatar,
      monthlyTarget: getMonthGoal(currentMonth + 1), // Meta dinâmica do mês atual
      currentMonthSales: closedContractsThisMonth
        .filter(p => p.closer_id === closer.id)
        .reduce((sum, p) => sum + (p.total_value || 0), 0),
      totalCommission: validProposals // Excluir propostas perdidas
        .filter(p => p.closer_id === closer.id)
        .reduce((sum, p) => sum + (p.commission || 0), 0),
      proposals: validProposals.filter(p => p.closer_id === closer.id)
    }));
  
  // Generate SDR stats from real employees data
  const sdrStats = employees
    .filter(emp => emp.role === 'SDR')
    .map(sdr => ({
      id: sdr.id,
      name: sdr.name,
      avatar: sdr.avatar,
      weeklyTarget: 3, // Could be stored in employee data
      currentWeekAppointments: proposals
        .filter(p => p.sdr_id === sdr.id && 
          new Date(p.created_at).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000)
        .length,
      monthlyAppointments: closedContractsThisMonth
        .filter(p => p.sdr_id === sdr.id)
        .length,
      totalCommission: validProposals // Excluir propostas perdidas
        .filter(p => p.sdr_id === sdr.id)
        .reduce((sum, p) => sum + (p.commission || 0), 0)
    }));


  const getProbabilityDisplay = (proposal: any) => {
    if (!proposal.probability_scores || !proposal.probability_scores.length) return 'Não avaliada';
    
    const scores = proposal.probability_scores[0];
    if (!scores) return 'Não avaliada';
    
    const total = (scores.economic_buyer || 0) + (scores.metrics || 0) + (scores.decision_criteria || 0) + 
                  (scores.decision_process || 0) + (scores.identify_pain || 0) + (scores.champion || 0) + 
                  (scores.competition || 0) + (scores.engagement || 0);
    
    if (total < 12) return 'Baixa';
    if (total <= 18) return 'Média';
    return 'Alta';
  };

  // Modal de detalhamento de comissões por pessoa
  const PersonCommissionModal: React.FC<{ employeeId: string; displayRate: number; onClose: () => void }> = ({ employeeId, displayRate, onClose }) => {
    const employee = employees.find(emp => emp.id === employeeId);
    if (!employee) return null;

    // Buscar APENAS propostas possíveis (Proposta e Negociação)
    const employeeProposals = possibleProposals.filter(p => 
      p.closer_id === employeeId || p.sdr_id === employeeId
    );

    // Separar por tipo de comissão
    const closerProposals = employeeProposals.filter(p => p.closer_id === employeeId);
    const sdrProposals = employeeProposals.filter(p => p.sdr_id === employeeId);

    // Calcular comissões usando a displayRate
    const totalCloserCommission = closerProposals.reduce((sum, p) => sum + ((p.total_value || 0) * displayRate / 100), 0);
    const totalSdrCommission = sdrProposals.reduce((sum, p) => sum + ((p.total_value || 0) * displayRate / 100), 0);
    const totalCommission = totalCloserCommission + totalSdrCommission;

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full mx-4 max-h-[80vh] overflow-y-auto">
          <div className="flex items-center justify-between p-6 border-b border-gray-200">
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Detalhamento de Comissões</h2>
              <p className="text-gray-600">{employee.name} - {employee.role} (Taxa: {displayRate}%)</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>
          
          <div className="p-6 space-y-6">
            {/* Resumo Total */}
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-green-900">Total de Comissões</h3>
                  <p className="text-sm text-green-700">
                    {closerProposals.length + sdrProposals.length} propostas possíveis • Taxa: {displayRate}%
                  </p>
                </div>
                <div className="text-2xl font-bold text-green-600">
                  {formatCurrency(totalCommission)}
                </div>
              </div>
            </div>

            {/* Comissões como Closer */}
            {closerProposals.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  Como Closer - {displayRate}% ({formatCurrency(totalCloserCommission)})
                </h3>
                <div className="space-y-3">
                  {closerProposals.map(proposal => (
                    <div key={`closer-${proposal.id}`} className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <h4 className="font-medium text-gray-900">{proposal.client}</h4>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            <span>Status: {proposal.status}</span>
                            <span>Taxa: {displayRate}%</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-bold text-blue-600">
                            {formatCurrency((proposal.total_value || 0) * displayRate / 100)}
                          </div>
                          <div className="text-sm text-gray-500">comissão</div>
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="text-gray-500">Valor Mensal:</span>
                          <div className="font-medium">
                            {formatCurrency(proposal.monthly_value || 0)}
                          </div>
                        </div>
                        <div>
                          <span className="text-gray-500">Duração:</span>
                          <div className="font-medium">{proposal.months} meses</div>
                        </div>
                        <div>
                          <span className="text-gray-500">Valor Global:</span>
                          <div className="font-medium text-green-600">
                            {formatCurrency(proposal.total_value || 0)}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Comissões como SDR */}
            {sdrProposals.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  Como SDR - {displayRate}% ({formatCurrency(totalSdrCommission)})
                </h3>
                <div className="space-y-3">
                  {sdrProposals.map(proposal => {
                    const sdrCommission = (proposal.total_value || 0) * displayRate / 100;
                    
                    return (
                      <div key={`sdr-${proposal.id}`} className="bg-green-50 border border-green-200 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <div>
                            <h4 className="font-medium text-gray-900">{proposal.client}</h4>
                            <div className="flex items-center space-x-4 text-sm text-gray-600">
                              <span>Status: {proposal.status}</span>
                              <span>Taxa: {displayRate}%</span>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-lg font-bold text-green-600">
                              {formatCurrency(sdrCommission)}
                            </div>
                            <div className="text-sm text-gray-500">comissão SDR</div>
                          </div>
                        </div>
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="text-gray-500">Valor Mensal:</span>
                            <div className="font-medium">
                              {formatCurrency(proposal.monthly_value || 0)}
                            </div>
                          </div>
                          <div>
                            <span className="text-gray-500">Duração:</span>
                            <div className="font-medium">{proposal.months} meses</div>
                          </div>
                          <div>
                            <span className="text-gray-500">Valor Global:</span>
                            <div className="font-medium text-green-600">
                              {formatCurrency(proposal.total_value || 0)}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Sem propostas */}
            {employeeProposals.length === 0 && (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Info className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhuma proposta encontrada</h3>
                <p className="text-gray-500">Este funcionário não possui propostas em aberto (Proposta ou Negociação)</p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Comercial Privado 2025</h1>
        <p className="text-gray-600">Visão geral do desempenho de vendas e comissões para {currentYear}</p>
      </div>

      {/* Meta Comercial - Card Principal */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <CommercialGoalCard />
      </div>

      {/* Título dos Indicadores Mensais */}
      <div className="border-t border-gray-200 pt-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Indicadores e resultados do mês atual</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <StatsCard
            title="Valor em Propostas Abertas"
            value={formatCurrency(totalOpenProposalValue)}
            icon={DollarSign}
            color="bg-blue-500"
            change="Propostas + Negociação"
            changeType="positive"
          />
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <StatsCard
            title="Possibilidade de comissão"
            value={formatCurrency(totalPossibleCommissions)}
            icon={Target}
            color="bg-green-500"
            change="Propostas em aberto"
            changeType="positive"
          />
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <StatsCard
            title="Agendamentos (SDRs)"
            value={totalAppointments}
            icon={Calendar}
            color="bg-purple-500"
            change="Visitas agendadas no mês"
            changeType="positive"
          />
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <StatsCard
            title="Negócios Fechados"
            value={closedDealsThisMonth}
            icon={TrendingUp}
            color="bg-orange-500"
            change="este mês"
            changeType="positive"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <SalesChart />
        </div>
        
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Propostas Ativas</h3>
          {activeProposals.length > 0 ? (
            <div className="space-y-4 max-h-80 overflow-y-auto">
            {activeProposals.map((proposal) => (
              <div key={proposal.id} className="border-l-4 border-blue-500 pl-4 py-2">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-900">
                    {proposal.client}
                  </span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    proposal.status === 'Negociação' ? 'bg-blue-100 text-blue-800' :
                    'bg-yellow-100 text-yellow-800'
                  }`}>
                    {proposal.status}
                  </span>
                </div>
                <p className="text-sm text-gray-600">
                  {formatCurrency(proposal.monthly_value || 0)} × {proposal.months} meses
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  Probabilidade: {getProbabilityDisplay(proposal)}
                </p>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-xs text-gray-500">
                    {new Date(proposal.updated_at || proposal.created_at).toLocaleDateString()}
                  </span>
                  <span className="text-xs font-medium text-green-600">
                    {formatCurrency(proposal.commission || 0)} comissão
                  </span>
                </div>
              </div>
            ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500">Nenhuma proposta ativa no momento</p>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <GuaranteedCommissions />
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <PossibleCommissions onShowPersonCommission={(employeeId, displayRate) => setShowPersonCommissionModal({employeeId, displayRate})} />
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* SUPERMETA Card */}
        {possibleProposals.length > 0 ? (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Supermeta</h2>
              
              {/* Meta Progress */}
              {totalClosedValueThisMonth >= 600000 ? (
                <div className="bg-gradient-to-r from-green-100 to-emerald-100 border-l-4 border-green-500 p-4 rounded-lg mb-4">
                  <p className="text-green-800 font-semibold text-center mb-3">
                    🎉 <strong>SUPERMETA CONQUISTADA!</strong> Parabéns! Vocês fecharam {formatCurrency(totalClosedValueThisMonth)} este mês!
                  </p>
                  <p className="text-green-700 text-center">
                    💰 <strong>Comissão de 0,8%</strong> garantida para todos os contratos do mês!
                  </p>
                </div>
              ) : (
                <div className="bg-gradient-to-r from-orange-100 to-red-100 border-l-4 border-orange-500 p-4 rounded-lg mb-4">
                  <p className="text-orange-800 font-semibold text-center mb-3">
                    🎯 <strong>Motivação:</strong> Feche {formatCurrency(600000)} em propostas nesse mês e receba o DOBRO das comissões
                  </p>
                </div>
              )}
              
              {/* Progress Bar */}
              <div className="mb-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Progresso da Supermeta:</span>
                    <span className="font-bold">{supermetaProgress.toFixed(1)}%</span>
                  </div>
                  <div className="w-full bg-orange-200 rounded-full h-3">
                    <div 
                      className={`h-3 rounded-full transition-all ${
                        totalClosedValueThisMonth >= 600000 
                          ? 'bg-gradient-to-r from-green-500 to-emerald-500' 
                          : 'bg-gradient-to-r from-orange-500 to-red-500'
                      }`}
                      style={{ width: `${supermetaProgress}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between text-xs text-orange-700">
                    <span>Fechado: {formatCurrency(totalClosedValueThisMonth)}</span>
                    <span>Meta: {formatCurrency(supermetaTarget)}</span>
                  </div>
                  {remainingToNextTier > 0 && (
                    <div className="text-center text-sm text-orange-700 mt-2">
                      <strong>Faltam {formatCurrency(remainingToNextTier)}</strong> para atingir a Supermeta
                    </div>
                  )}
                </div>
              </div>
              
              <div className="text-center mb-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-600">Comissões Atuais (0,4%):</span>
                    <div className="font-bold text-blue-600">
                      {formatCurrency(totalPossibleCommissions)}
                    </div>
                  </div>
                  <div>
                    <span className="text-gray-600">Supermeta (0,8%):</span>
                    <div className="font-bold text-orange-600">
                      {formatCurrency(supermetaCommissions)}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {employees.length > 0 ? (
              <div className="space-y-4">
              {employees.filter(emp => emp.role !== 'Admin').map((employee, index) => (
                <div key={employee.id} className="flex items-center space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                      {index + 1}
                    </div>
                  </div>
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    employee.role === 'Closer' ? 'bg-blue-100' : 
                    employee.role === 'SDR' ? 'bg-green-100' : 'bg-purple-100'
                  }`}>
                    <Target className={`w-5 h-5 ${
                      employee.role === 'Closer' ? 'text-blue-600' : 
                      employee.role === 'SDR' ? 'text-green-600' : 'text-purple-600'
                    }`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900">{employee.name}</p>
                    <p className="text-xs text-gray-500">
                      {employee.role} • {employee.department}
                    </p>
                  </div>
                  <button 
                    onClick={() => setShowPersonCommissionModal({employeeId: employee.id, displayRate: 0.8})}
                    className="text-sm font-semibold text-orange-600 hover:text-orange-700 transition-colors cursor-pointer flex items-center space-x-1"
                    title="Clique para ver detalhes"
                  >
                    <span>
                    {formatCurrency(possibleProposals
                      .filter(p => p.closer_id === employee.id || p.sdr_id === employee.id)
                      .reduce((sum, p) => {
                        let employeeCommission = 0;
                        
                        // Se é Closer desta proposta
                        if (p.closer_id === employee.id) {
                          employeeCommission += (p.total_value || 0) * 0.008; // 0.8% para Supermeta
                        }
                        
                        // Se é SDR desta proposta (recebe 0.8% também)
                        if (p.sdr_id === employee.id) {
                          employeeCommission += (p.total_value || 0) * 0.008; // 0.8% para Supermeta
                        }
                        
                        return sum + employeeCommission;
                      }, 0))}
                    </span>
                    <Info className="w-3 h-3" />
                  </button>
                </div>
              ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500">Nenhum funcionário cadastrado</p>
              </div>
            )}
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhuma Proposta Ativa</h3>
              <p className="text-gray-500">Crie propostas na aba "Propostas" para ativar a Supermeta</p>
            </div>
          </div>
        )}
        
        {/* MEGAMETA Card */}
        {possibleProposals.length > 0 ? (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Megameta</h2>
              
              {/* Meta Progress */}
              {totalClosedValueThisMonth >= 1200000 ? (
                <div className="bg-gradient-to-r from-purple-100 to-indigo-100 border-l-4 border-purple-500 p-4 rounded-lg mb-4">
                  <p className="text-purple-800 font-semibold text-center mb-3">
                    🚀 <strong>MEGAMETA CONQUISTADA!</strong> Parabéns! Vocês fecharam {formatCurrency(totalClosedValueThisMonth)} este mês!
                  </p>
                  <p className="text-purple-700 text-center">
                    💎 <strong>Comissão de 1,2%</strong> garantida para todos os contratos do mês!
                  </p>
                </div>
              ) : (
                <div className="bg-gradient-to-r from-purple-100 to-indigo-100 border-l-4 border-purple-500 p-4 rounded-lg mb-4">
                  <p className="text-purple-800 font-semibold text-center mb-3">
                    🚀 <strong>Motivação:</strong> Feche {formatCurrency(1200000)} em propostas nesse mês e receba o TRIPLO das comissões
                  </p>
                </div>
              )}
              
              {/* Progress Bar */}
              <div className="mb-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Progresso da Megameta:</span>
                    <span className="font-bold">{((totalClosedValueThisMonth / 1200000) * 100).toFixed(1)}%</span>
                  </div>
                  <div className="w-full bg-purple-200 rounded-full h-3">
                    <div 
                      className={`h-3 rounded-full transition-all ${
                        totalClosedValueThisMonth >= 1200000 
                          ? 'bg-gradient-to-r from-purple-500 to-indigo-500' 
                          : 'bg-gradient-to-r from-purple-500 to-indigo-500'
                      }`}
                      style={{ width: `${Math.min((totalClosedValueThisMonth / 1200000) * 100, 100)}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between text-xs text-purple-700">
                    <span>Fechado: {formatCurrency(totalClosedValueThisMonth)}</span>
                    <span>Meta: {formatCurrency(1200000)}</span>
                  </div>
                  {totalClosedValueThisMonth < 1200000 && (
                    <div className="text-center text-sm text-purple-700 mt-2">
                      <strong>Faltam {formatCurrency(1200000 - totalClosedValueThisMonth)}</strong> para atingir a Megameta
                    </div>
                  )}
                </div>
              </div>
              
              <div className="text-center mb-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-600">Comissões Atuais (0,4%):</span>
                    <div className="font-bold text-blue-600">
                      {formatCurrency(totalPossibleCommissions)}
                    </div>
                  </div>
                  <div>
                    <span className="text-gray-600">Megameta (1,2%):</span>
                    <div className="font-bold text-purple-600">
                      {formatCurrency(possibleProposals.reduce((sum, p) => {
                        const closerCommission = p.closer_id ? (p.total_value || 0) * 0.012 : 0;
                        const sdrCommission = p.sdr_id ? (p.total_value || 0) * 0.012 : 0;
                        return sum + closerCommission + sdrCommission;
                      }, 0))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {employees.filter(emp => emp.role !== 'Admin').length > 0 ? (
              <div className="space-y-4">
              {employees.filter(emp => emp.role !== 'Admin').map((employee, index) => (
                <div key={employee.id} className="flex items-center space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                      {index + 1}
                    </div>
                  </div>
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    employee.role === 'Closer' ? 'bg-blue-100' : 
                    employee.role === 'SDR' ? 'bg-green-100' : 'bg-purple-100'
                  }`}>
                    <Target className={`w-5 h-5 ${
                      employee.role === 'Closer' ? 'text-blue-600' : 
                      employee.role === 'SDR' ? 'text-green-600' : 'text-purple-600'
                    }`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900">{employee.name}</p>
                    <p className="text-xs text-gray-500">
                      {employee.role} • {employee.department}
                    </p>
                  </div>
                  <button 
                    onClick={() => setShowPersonCommissionModal({employeeId: employee.id, displayRate: 1.2})}
                    className="text-sm font-semibold text-purple-600 hover:text-purple-700 transition-colors cursor-pointer flex items-center space-x-1"
                    title="Clique para ver detalhes"
                  >
                    <span>
                    {formatCurrency(possibleProposals
                      .filter(p => p.closer_id === employee.id || p.sdr_id === employee.id)
                      .reduce((sum, p) => {
                        let employeeCommission = 0;
                        
                        // Se é Closer desta proposta
                        if (p.closer_id === employee.id) {
                          employeeCommission += (p.total_value || 0) * 0.012; // 1.2% para Megameta
                        }
                        
                        // Se é SDR desta proposta (recebe 1.2% também)
                        if (p.sdr_id === employee.id) {
                          employeeCommission += (p.total_value || 0) * 0.012; // 1.2% para Megameta
                        }
                        
                        return sum + employeeCommission;
                      }, 0))}
                    </span>
                    <Info className="w-3 h-3" />
                  </button>
                </div>
              ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500">Nenhum funcionário cadastrado</p>
              </div>
            )}
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhuma Proposta Ativa</h3>
              <p className="text-gray-500">Crie propostas na aba "Propostas" para ativar a Megameta</p>
            </div>
          </div>
        )}
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <EmployeeHighlight />
        </div>
      </div>
      
      {/* Modal de detalhamento de comissões por pessoa */}
      {showPersonCommissionModal && (
        <PersonCommissionModal 
          employeeId={showPersonCommissionModal.employeeId}
          displayRate={showPersonCommissionModal.displayRate}
          onClose={() => setShowPersonCommissionModal(null)} 
        />
      )}
    </div>
  );
});